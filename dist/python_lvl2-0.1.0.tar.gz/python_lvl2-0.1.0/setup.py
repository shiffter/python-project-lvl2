# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['generate_diff', 'generate_diff.modules', 'generate_diff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=3.0.0,<4.0.0']

entry_points = \
{'console_scripts': ['gendiff = generate_diff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'python-lvl2',
    'version': '0.1.0',
    'description': 'Generate diff',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
